O:41:"Symfony\Component\AssetMapper\MappedAsset":10:{s:10:"sourcePath";s:108:"/home/reboot-student/code/projects/project2-eCommerce-heroTask/webApp/assets/controllers/hello_controller.js";s:10:"publicPath";s:72:"/assets/controllers/hello_controller-55882fcad241d2bea50276ea485583bc.js";s:23:"publicPathWithoutDigest";s:39:"/assets/controllers/hello_controller.js";s:15:"publicExtension";s:2:"js";s:7:"content";s:500:"import { Controller } from '@hotwired/stimulus';

/*
 * This is an example Stimulus controller!
 *
 * Any element with a data-controller="hello" attribute will cause
 * this controller to be executed. The name "hello" comes from the filename:
 * hello_controller.js -> "hello"
 *
 * Delete this file or adapt it for your use!
 */
export default class extends Controller {
    connect() {
        this.element.textContent = 'Hello Stimulus! Edit me in assets/controllers/hello_controller.js';
    }
}
";s:6:"digest";s:32:"55882fcad241d2bea50276ea485583bc";s:13:"isPredigested";b:0;s:55:" Symfony\Component\AssetMapper\MappedAsset dependencies";a:0:{}s:59:" Symfony\Component\AssetMapper\MappedAsset fileDependencies";a:0:{}s:11:"logicalPath";s:31:"controllers/hello_controller.js";}