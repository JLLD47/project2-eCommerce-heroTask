O:41:"Symfony\Component\AssetMapper\MappedAsset":10:{s:10:"sourcePath";s:91:"/home/reboot-student/code/projects/project2-eCommerce-heroTask/webApp/assets/styles/app.css";s:10:"publicPath";s:55:"/assets/styles/app-00a11f193477fd19da17eaa5619f3aee.css";s:23:"publicPathWithoutDigest";s:22:"/assets/styles/app.css";s:15:"publicExtension";s:3:"css";s:7:"content";s:98:"body {
    background-color: skyblue;
}
@tailwind base;
@tailwind components;
@tailwind utilities;";s:6:"digest";s:32:"00a11f193477fd19da17eaa5619f3aee";s:13:"isPredigested";b:0;s:55:" Symfony\Component\AssetMapper\MappedAsset dependencies";a:0:{}s:59:" Symfony\Component\AssetMapper\MappedAsset fileDependencies";a:0:{}s:11:"logicalPath";s:14:"styles/app.css";}