O:41:"Symfony\Component\AssetMapper\MappedAsset":10:{s:10:"sourcePath";s:125:"/home/reboot-student/code/projects/project2-eCommerce-heroTask/webApp/vendor/symfony/ux-turbo/assets/dist/turbo_controller.js";s:10:"publicPath";s:78:"/assets/@symfony/ux-turbo/turbo_controller-ce5e32dafdec0b7752f02e3e2cb25751.js";s:23:"publicPathWithoutDigest";s:45:"/assets/@symfony/ux-turbo/turbo_controller.js";s:15:"publicExtension";s:2:"js";s:7:"content";s:163:"import { Controller } from '@hotwired/stimulus';
import '@hotwired/turbo';

class turbo_controller extends Controller {
}

export { turbo_controller as default };
";s:6:"digest";s:32:"ce5e32dafdec0b7752f02e3e2cb25751";s:13:"isPredigested";b:0;s:55:" Symfony\Component\AssetMapper\MappedAsset dependencies";a:0:{}s:59:" Symfony\Component\AssetMapper\MappedAsset fileDependencies";a:0:{}s:11:"logicalPath";s:37:"@symfony/ux-turbo/turbo_controller.js";}